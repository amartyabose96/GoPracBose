<?php
$conn = new mysqli('localhost','root','','student');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Codes</title>
    <link href="student_registered_items/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="student_registered_items/js/script.js"></script>
    <link href="student_registered_items/css/style.css" rel="stylesheet">
</head>

<body style="margin-top: 2%; background: linear-gradient(45deg, yellow, green, yellow);">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <h3>
                    Students Registered
                </h3>
            </div>
        </div>
        <br>
        <div class="row">
            <div class="col-md-12">
                <table id="data" class="table table-hover">
                    <thead>
                        <tr>
                            <th>
                                First Name
                            </th>
                            <th>
                                Last Name
                            </th>
                            <th>
                                Gender
                            </th>
                            <th>
                                E-mail
                            </th>
                            <th>
                                Phone Number
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $sql = "SELECT * FROM registration";
                            $result = $conn->query($sql);
                            while($rows = $result->fetch_assoc())
                            {
                        ?>
                        <tr>
                            <td><?php echo $rows['firstName']; ?></td>
                            <td><?php echo $rows['lastName']; ?></td>
                            <td><?php echo $rows['gender']; ?></td>
                            <td><?php echo $rows['email']; ?></td>
                            <td><?php echo $rows['number']; ?></td>
                        </tr>
                        <?php
                            }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <script src="student_registered_items/js/jquery.min.js"></script>
    <script src="student_registered_items/js/bootstrap.min.js"></script>
    <script src="student_registered_items/js/scripts.js"></script>
<?php $conn->close(); ?>
</body>

</html>