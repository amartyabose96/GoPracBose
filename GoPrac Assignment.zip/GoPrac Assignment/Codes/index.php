<?php
$conn = new mysqli('localhost','root','','codes');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Codes</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="js/script.js"></script>
    <link href="css/style.css" rel="stylesheet">
</head>

<body style="margin-top: 2%; background: linear-gradient(45deg, green, yellow, green, yellow, green);">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <h3>
                    Alphanumeric Codes
                </h3>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <form action="code_connect.php" method="post" role="form">
                    <div class="form-group">
                        <label>
						Enter A Code
					</label>
                        <input class="form-control" id="number" name="number">
                    </div>
                    <button type="submit" class="btn btn-primary" name="regular">
					Submit
				</button>
                </form>
            </div>
        </div>
        <div class="container-fluid">
	<div class="row">
		<div class="col-md-12">
			<h3 class="text-center">
				Sorting and Searching
			</h3>
		</div>
	</div>
	<div class="row">
		<div class="col-md-3">
            <form role="form" action="<?php $_SERVER['PHP_SELF'] ?>" method = "post"> 
				<button type="submit" name="sort-by-code" id="sort-by-code" class="btn btn-primary sort-button">
					Sort By Code Z-A
				</button>
			</form>
		</div>
        <div class="col-md-3">
            <form role="form" action="<?php $_SERVER['PHP_SELF'] ?>" method = "post"> 
				<button type="submit" name="sort-by-code-asc" id="sort-by-code-asc" class="btn btn-primary sort-button">
					Sort By Code A-Z
				</button>
			</form>
		</div>
		<div class="col-md-3">
			<form role="form" action="<?php $_SERVER['PHP_SELF'] ?>" method = "post">
				<div class="form-group">
					<label>
						Enter Code
					</label>
					<input class="form-control" name="code-search-box" id="code-search-box" />
				</div> 
				<button type="submit" name="code-search" id="code-search" class="btn btn-primary">
					Submit
				</button>
			</form>
		</div>
        <br>
		<div class="col-md-3">
			<form role="form" action="<?php $_SERVER['PHP_SELF'] ?>" method = "post">
				<div class="form-group">	 
					<label>
						Enter Start Date (YYYY-MM-DD)
					</label>
					<input class="form-control" id="date-input-box" name="date-input-box" />
				</div>
                <div class="form-group">	 
					<label>
						Enter End Date (YYYY-MM-DD)
					</label>
					<input class="form-control" id="enddate-input-box" name="enddate-input-box" />
				</div>
				<button type="submit" id="date-input-button" name="date-input-button" class="btn btn-primary">
					Submit
				</button>
			</form>
		</div>
	</div>
</div>
        <br>
        <div class="row">
            <div class="col-md-12">
                <table id="data" class="table table-hover">
                    <thead>
                        <tr>
                            <th>
                                Code
                            </th>
                            <th>
                                Start Date
                            </th>
                            <th>
                                End Date
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            if(isset($_POST['sort-by-code-asc'])){
                                $sql = "SELECT code, startDate, endDate FROM codes ORDER BY code ASC";
                                $result = $conn->query($sql);
                                while($rows = $result->fetch_assoc())
                                {
                        ?>
                        <tr>
                            <td><?php echo $rows['code']; ?></td>
                            <td><?php echo $rows['startDate']; ?></td>
                            <td><?php echo $rows['endDate']; ?></td>
                        </tr>
                        <?php
                            }
                        }else if(isset($_POST['sort-by-code'])){
                                $sql = "SELECT code, startDate, endDate FROM codes ORDER BY code DESC";
                                $result = $conn->query($sql);
                                while($rows = $result->fetch_assoc())
                                {
                        ?>
                        <tr>
                            <td><?php echo $rows['code']; ?></td>
                            <td><?php echo $rows['startDate']; ?></td>
                            <td><?php echo $rows['endDate']; ?></td>
                        </tr>
                        <?php
                            }
                        }
                        else if(isset($_POST['code-search'])){
                            if(!empty($_POST['code-search-box']))
                                $codeSearch = $_POST['code-search-box'];
                            $sql = "SELECT code, startDate, endDate FROM codes where code='$codeSearch' ";
                            $result = $conn->query($sql);
                            while($rows = $result->fetch_assoc())
                            {
                        ?>
                        <tr>
                            <td><?php echo $rows['code']; ?></td>
                            <td><?php echo $rows['startDate']; ?></td>
                            <td><?php echo $rows['endDate']; ?></td>
                        </tr>
                        <?php
                            }
                        }
                        else if(isset($_POST['date-input-button'])){
                            if(!empty($_POST['date-input-box'])){
                                $dateSearch = $_POST['date-input-box'];
                                $dateSearchEnd = $_POST['enddate-input-box'];
                            }
                            $sql = "SELECT code, startDate, endDate FROM codes where startDate BETWEEN '$dateSearch' AND '$dateSearchEnd' ";
                            $result = $conn->query($sql);
                            while($rows = $result->fetch_assoc())
                            {
                        ?>
                        <tr>
                            <td><?php echo $rows['code']; ?></td>
                            <td><?php echo $rows['startDate']; ?></td>
                            <td><?php echo $rows['endDate']; ?></td>
                        </tr>
                        <?php
                            }
                        }
                        else{
                            $sql = "SELECT code, startDate, endDate FROM codes";
                            $result = $conn->query($sql);
                            while($rows = $result->fetch_assoc())
                            {
                        ?>
                        <tr>
                            <td><?php echo $rows['code']; ?></td>
                            <td><?php echo $rows['startDate']; ?></td>
                            <td><?php echo $rows['endDate']; ?></td>
                        </tr>
                        <?php
                            }
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="row">
            <div style="margin-left: 40%" class="col-md-12">
                <form action="code_connect_edit.php" method="post" role="form">
                    <div class="form-group">
                        <label>
						Enter A Code To Change Its Start Date
					</label>
                        <input style="width: 10%; margin-bottom: 2%; margin-left: 4%" class="form-control" id="edit-box" name="edit-box">
                    </div>
                    <button style="margin-left: 6%" type="submit" class="btn btn-primary" id="edit-button" name="edit-button">
					Submit
				</button>
                </form>
            </div>
        </div>
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/scripts.js"></script>
<?php $conn->close(); ?>
</body>

</html>