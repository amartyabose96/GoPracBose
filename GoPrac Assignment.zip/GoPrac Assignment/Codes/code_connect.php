<?php 
$number = substr(str_shuffle("0123456789abcdefghijklmnopqrstvwxyz"), 0, 6);
$startDate = date('Y-m-d');
$endDate = date('Y-m-d', strtotime( $startDate . " +1 year"));
$conn = new mysqli('localhost','root','','codes');

if($conn->connect_error){
    echo "$conn->connect_error";
    die("Connection Failed : ". $conn->connect_error);
} else {
    $stmt = $conn->prepare("insert into codes(code, startDate, endDate) values(?, ?, ?)");
    $stmt->bind_param("sss", $number, $startDate, $endDate);
    $execval = $stmt->execute();
    echo "Added...";
    $stmt->close();
    $conn->close();
} 
?>