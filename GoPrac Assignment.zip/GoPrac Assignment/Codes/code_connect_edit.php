<?php 
$number = $_POST['edit-box'];
$startDate = date('Y-m-d');
$endDate = date('Y-m-d', strtotime( $startDate . " +1 year"));
$conn = new mysqli('localhost','root','','codes');

if($conn->connect_error){
    echo "$conn->connect_error";
    die("Connection Failed : ". $conn->connect_error);
} else {
    $stmt = $conn->prepare("UPDATE codes SET startDate ='$startDate', endDate ='$endDate' where code='$number' ");
    $execval = $stmt->execute();
    echo "Updated...";
    $stmt->close();
    $conn->close();
} 
?>